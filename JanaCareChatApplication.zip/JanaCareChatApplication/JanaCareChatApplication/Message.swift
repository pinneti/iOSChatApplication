//
//  Message.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 01/05/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import Foundation

class Package {
    
    var messages : [Message] =   [Message]()
    var date : String?
    
    init(json : JSON){
        date = json["date"].string
        if let items = json["messages"].array{
          
            for item in items{
              
                let msg = Message(json: item)
                
                 messages.append(msg)
            }
        
        }
    }
    

}

class Message{
    
    var message : String?
    var time : String?
    var type : MessageType?
    var status : MessageStatus?
    
    
    init(message : String?, status : String?, time : String?, type : String? )
    {
        if let message = message{
            self.message = message
        }
        
        if let time = time {
            self.time = time
        }
        
        if let type = type {
            if type == "inbox"{
                self.type = .inbox
            }
            else {
                self.type = .outbox
            }
        }
        
        if let str = status{
            
            
            if  str == "delivered"{
                self.status = .Delivered
            }
            else if str == "pending"{
                self.status = .Pending
            }
            else if str == "recieved"{
                self.status = .Received
            }
            else{
                self.status = .SendingFailed
            }
        
        }
        
        
       
        
    }
    
    init(json : JSON?){
        if let json = json{
            message = json["message"].string
            time =  json["time"].string
            if let type = json["type"].string{
                if type == "inbox"{
                     self.type = .inbox
                }
                else {
                    self.type = .outbox
                }
            
            }
            if let str = json["status"].string{
                
                if  str == "delivered"{
                    status = .Delivered
                }
                else if str == "pending"{
                    status = .Pending
                }
                else if str == "recieved"{
                    status = .Received
                }
                else{
                    status = .SendingFailed
                }
                
            }
        }
        
    }
}

enum MessageStatus {
    case Pending, Delivered, SendingFailed, Received
}

enum MessageType {
    case inbox,outbox
}


