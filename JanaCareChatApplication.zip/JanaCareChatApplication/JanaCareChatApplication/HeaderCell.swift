//
//  HeaderCell.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 02/05/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import UIKit

class HeaderCell: UITableViewCell {
   
    
    @IBOutlet weak var titleLabel: UILabel!
    
    func cellConfigure(title : String){
          titleLabel.text = title
    }
    
}
