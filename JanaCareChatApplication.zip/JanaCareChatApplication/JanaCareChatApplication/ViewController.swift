//
//  ViewController.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 28/04/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var sendButton: UIButton!
    
    
    @IBOutlet weak var textField: UITextField!
    
    
    @IBOutlet weak var bottomLayoutConstraint: NSLayoutConstraint!
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var packages : [Package] = [Package]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.estimatedRowHeight = 80
        self.tableView.rowHeight = UITableViewAutomaticDimension
        //self.tableView.setNeedsLayout()
        //self.tableView.layoutIfNeeded()
        
       
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ViewController.keyboardWillShow), name: UIKeyboardWillShowNotification, object: nil)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ViewController.keyboardWillHide), name: UIKeyboardWillHideNotification, object: nil)
        

        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
        
        // Do any additional setup after loading the view, typically from a nib.
    }


    func keyboardWillShow(notification:NSNotification) {
         adjustingHeight(true, notification: notification)
    }
    
    func keyboardWillHide(notification:NSNotification) {
          adjustingHeight(false, notification: notification)
    }

    
    func adjustingHeight(show:Bool, notification:NSNotification) {
        // 1
        var userInfo = notification.userInfo!
        // 2
        let keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).CGRectValue()
        // 3
        let animationDurarion = userInfo[UIKeyboardAnimationDurationUserInfoKey] as! NSTimeInterval
        // 4
        let changeInHeight = (CGRectGetHeight(keyboardFrame)) * (show ? 1 : -1)
        //5
        UIView.animateWithDuration(animationDurarion, animations: { () -> Void in
            self.bottomLayoutConstraint.constant += changeInHeight
        })
        
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        getDataFromNetwork()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    

}


extension ViewController{

    func getDataFromNetwork(){
       
        let url = NSURL(string: "http://www.json-generator.com/api/json/get/bPJwJPdGTC?indent=2")
        
        let task = NSURLSession.sharedSession().dataTaskWithURL(url!) {(data, response, error) in
         
            
            if let error = error {
                
                print(error)
            }
            else{
                
                 print(NSString(data: data!, encoding: NSUTF8StringEncoding))
                
             
              
          
                do {
                    let json = try JSON(data: data!)
                    
                    print(json)
                    if let items = json["response"].array{
                        
                        for item in items{
                            print("\n\n")
                            print(item)
                            let package = Package(json: item["Package"])
                            self.packages.append(package)
                        }
                        
                    }
                    
                    
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.tableView.reloadData()
                    })
                    
                } catch {
                    // Handle errors
                }
              
            
                
              
                
               
            }
            
        }
        
        task.resume()
    
    
    }
    
    

}

extension ViewController : UITableViewDataSource{
   
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
       
        return packages[section].messages.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return packages.count
    }
    

    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
    
        
               let cell : HeaderCell = tableView.dequeueReusableCellWithIdentifier("headercell") as! HeaderCell
               cell.cellConfigure(packages[section].date!)
        
              return cell
       
    }
    
//    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat{
//        
//        if section == packages.count - 1{
//            
//            return 30.0
//        }
//        
//        return 0.0
//    }
//    
//    
//    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
//            if section == packages.count - 1{
//                
//                let cell : FooterCell = tableView.dequeueReusableCellWithIdentifier("footercell") as! FooterCell
//                //cell.cellConfigure(packages[section].date!)
//                
//                return cell
//                
//                
//            }
//        return nil
//    }
//    
    
    
   
  
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
       
        
         let message =  packages[indexPath.section].messages[indexPath.row]
         
            if message.type == .inbox{
                let cell : RightChatTableViewCell = tableView.dequeueReusableCellWithIdentifier("rightchattableviewcell") as! RightChatTableViewCell
                cell.cellConfigure(message.message,status : message.status)
                return cell
            }
            else{
               
                let cell : LeftChatTableViewCell = tableView.dequeueReusableCellWithIdentifier("leftchattableviewcell") as! LeftChatTableViewCell
                cell.cellConfigure(message.message)
                return cell
            
            }
        
        
    }
    
   

    
   
    
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    

}



extension ViewController :UITextFieldDelegate {
   
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        if range.location == 0 && range.length == 0{
           sendButton.enabled = true
        }
        else if range.location == 0 && range.length == 1{
            
            sendButton.enabled = false
        }

        return true;
    }
    
    
 
    @IBAction func sendMessageButtonAction(sender: AnyObject) {
        
        let msg = Message(message: textField.text, status: "delivered", time: nil, type: "inbox")
        if packages.count > 0{
           packages[packages.count-1].messages.append(msg)
        }
        textField.text = ""
        sendButton.enabled = false
        tableView.reloadData()
        
        let path = NSIndexPath(forRow: packages[packages.count-1].messages.count-1, inSection: packages.count-1)
        tableView.scrollToRowAtIndexPath(path, atScrollPosition: .Bottom, animated: true)
     
    }
    
    

}



