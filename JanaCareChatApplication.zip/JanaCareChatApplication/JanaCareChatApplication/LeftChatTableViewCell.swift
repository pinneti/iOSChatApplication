//
//  LeftChatTableViewCell.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 01/05/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import UIKit

class LeftChatTableViewCell: UITableViewCell {

    
    @IBOutlet weak var messageLabel: ChatLabel!
    
    @IBOutlet weak var messageLabelWidthConstraint: NSLayoutConstraint!
    
    
    func cellConfigure(msg : String?){
        if let msg = msg{
         
            
             self.selectionStyle = UITableViewCellSelectionStyle.None
            messageLabel.text = msg
            messageLabel.preferredMaxLayoutWidth = 540.0
            // Swift
            messageLabel.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
            messageLabel.numberOfLines = 0
            
            let width = widthForView(msg, font:messageLabel.font)
            
            if(width > UIScreen.mainScreen().bounds.width - 123) {
                messageLabelWidthConstraint.constant = UIScreen.mainScreen().bounds.width - 123
            }
            else{
                messageLabelWidthConstraint.constant = width + 30
            }
            
        }
        
        
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        messageLabel.layer.masksToBounds = true
        messageLabel.layer.cornerRadius = 15
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    func widthForView(text: String?, font: UIFont) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, CGFloat.max, 16.5))
        label.numberOfLines = 1
        label.font = font
        label.text = text
        
        label.sizeToFit()
        return label.frame.width
    }

}



class ChatLabel : UILabel{

    let padding = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
    
    override func drawTextInRect(rect: CGRect) {
        super.drawTextInRect(UIEdgeInsetsInsetRect(rect, padding))
        
    }
    
    
    
    // Override -intrinsicContentSize: for Auto layout code
    override func intrinsicContentSize() -> CGSize {
        let superContentSize = super.intrinsicContentSize()
        let width = superContentSize.width + padding.left + padding.right
        let heigth = superContentSize.height + padding.top + padding.bottom
        return CGSize(width: width, height: heigth)
    }
    
    // Override -sizeThatFits: for Springs & Struts code
    override func sizeThatFits(size: CGSize) -> CGSize {
        let superSizeThatFits = super.sizeThatFits(size)
        let width = superSizeThatFits.width + padding.left + padding.right
        let heigth = superSizeThatFits.height + padding.top + padding.bottom
        return CGSize(width: width, height: heigth)
    }


}
