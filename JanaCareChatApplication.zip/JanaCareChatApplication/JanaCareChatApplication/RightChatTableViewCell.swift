//
//  RightChatTableViewCell.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 01/05/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import UIKit

class RightChatTableViewCell: UITableViewCell {

    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var messageLabel: ChatLabel!
    
    @IBOutlet weak var messageLabelWidthConstraint: NSLayoutConstraint!
   
    
    
    func cellConfigure(msg : String?,status : MessageStatus?){
        if let msg = msg{
            messageLabel.text = msg
            messageLabel.preferredMaxLayoutWidth = 540.0
            self.selectionStyle = UITableViewCellSelectionStyle.None
            // Swift
            messageLabel.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
            messageLabel.numberOfLines = 0
            
            if let status = status {
                if status == .Delivered{
                    statusLabel.text =  "Delivered"
                 }
                else{
                    statusLabel.textColor = UIColor.redColor()
                    statusLabel.text = "Not Delivered"
                }
            }
            
            let width = widthForView(msg, font:messageLabel.font)
            
            if(width > UIScreen.mainScreen().bounds.width - 123) {
               messageLabelWidthConstraint.constant = UIScreen.mainScreen().bounds.width - 123
            }
            else{
               messageLabelWidthConstraint.constant = width + 30
            }
        }
        
    }
    

    override func awakeFromNib() {
        super.awakeFromNib()
        messageLabel.layer.masksToBounds = true
        messageLabel.layer.cornerRadius = 15
        
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        statusLabel.textColor = UIColor.lightGrayColor()
    }
    
    
     func widthForView(text: String?, font: UIFont) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, CGFloat.max, 16.5))
        label.numberOfLines = 1
        label.font = font
        label.text = text
        
        label.sizeToFit()
        return label.frame.width
    }
    
    

}
