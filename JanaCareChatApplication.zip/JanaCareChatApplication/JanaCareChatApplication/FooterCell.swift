//
//  FooterCell.swift
//  JanaCareChatApplication
//
//  Created by chandra mohana on 02/05/16.
//  Copyright © 2016 chandra mohana. All rights reserved.
//

import UIKit

class FooterCell: UITableViewCell {

   
    
    
    @IBOutlet weak var typingIndicatorImage: UIImageView!
    
    override func awakeFromNib() {
        //typingIndicatorImage.animationImages
       
        
    }
    
    
}
